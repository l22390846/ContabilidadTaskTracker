package com.example.contabilidad_task_tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.contabilidad_task_tracker.ui.theme.ContabilidadTaskTrackerTheme
import com.example.contabilidad_task_tracker.view.TaskScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ContabilidadTaskTrackerTheme {
                TaskScreen()
            }
        }
    }
}
