package com.example.contabilidad_task_tracker.data

import androidx.room.Database
import androidx.room.RoomDatabase

/**
 * Base de Datos (Room)
 *
 * Responsabilidades:
 * - Definir las entidades (tablas) que conforman la BD local.
 * - Proveer los DAO (interfaces) para acceder a los datos.
 *
 * Configuración:
 * - entities: lista de tablas (Entity) incluidas.
 * - version: versión del esquema de la BD (incrementa si haces cambios en tablas).
 * - exportSchema: false para no exportar el esquema (útil si no lo requieren en el proyecto).
 */
@Database(
    entities = [TaskEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    /**
     * DAO principal para operaciones sobre tareas.
     * Se usa en el ViewModel para consultar y modificar la BD.
     */
    abstract fun taskDao(): TaskDao
}
