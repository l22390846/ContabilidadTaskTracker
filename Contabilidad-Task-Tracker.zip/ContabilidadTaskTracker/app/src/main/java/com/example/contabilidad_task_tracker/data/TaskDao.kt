package com.example.contabilidad_task_tracker.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * DAO (Data Access Object)
 * Capa de acceso a datos para la tabla "tasks".
 *
 * Responsabilidades:
 * - Consultar tareas (en tiempo real mediante Flow)
 * - Insertar / actualizar tareas (upsert)
 * - Actualizar estado de completado (isDone)
 * - Eliminar tareas completadas o todas
 *
 * Nota:
 * Este DAO NO contiene lógica de negocio. Solo define operaciones SQL.
 * La lógica (validación/filtros) vive en el ViewModel.
 */
@Dao
interface TaskDao {

    /**
     * Observa todas las tareas almacenadas en BD.
     * Devuelve un Flow para que la UI se actualice en tiempo real cuando la BD cambia.
     * Orden: más recientes primero (createdAt DESC).
     */
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<TaskEntity>>

    /**
     * Inserta una tarea o la reemplaza si ya existe el mismo id.
     * Usamos REPLACE para permitir "upsert".
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskEntity)

    /**
     * Actualiza el estado de completada (isDone) de una tarea por su id.
     * @param taskId id de la tarea
     * @param done nuevo valor booleano para isDone
     */
    @Query("UPDATE tasks SET isDone = :done WHERE id = :taskId")
    suspend fun setDone(taskId: String, done: Boolean)

    /**
     * Elimina todas las tareas marcadas como completadas (isDone = 1).
     */
    @Query("DELETE FROM tasks WHERE isDone = 1")
    suspend fun deleteCompleted()

    /**
     * Elimina TODAS las tareas de la tabla.
     * Útil para reiniciar la lista.
     */
    @Query("DELETE FROM tasks")
    suspend fun deleteAll()
}
