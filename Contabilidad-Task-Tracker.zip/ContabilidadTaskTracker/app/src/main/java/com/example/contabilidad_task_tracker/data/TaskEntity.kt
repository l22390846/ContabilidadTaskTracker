package com.example.contabilidad_task_tracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity (Room) - Tabla: "tasks"
 *
 * Representa el formato PERSISTENTE de una tarea en la base de datos local.
 * Esta clase pertenece a la capa de datos (Data Layer).
 *
 * Campos:
 * @property id Identificador único de la tarea (Primary Key).
 * @property title Título o descripción de la tarea.
 * @property isDone Indica si la tarea está completada.
 * @property createdAt Fecha/hora de creación en milisegundos (System.currentTimeMillis()).
 */
@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val isDone: Boolean,
    val createdAt: Long
)
