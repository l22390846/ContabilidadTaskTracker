package com.example.contabilidad_task_tracker.model

import java.util.UUID

data class TaskItem(
    val id: String,
    val title: String,
    val isDone: Boolean = false

)
