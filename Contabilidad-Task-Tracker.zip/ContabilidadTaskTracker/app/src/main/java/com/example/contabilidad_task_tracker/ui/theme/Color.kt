package com.example.contabilidad_task_tracker.ui.theme


import androidx.compose.ui.graphics.Color


val TecGreen = Color(0xFF163E32)     // #163E32
val TecOrange = Color(0xFFF79633)    // #F79633
val TecGray = Color(0xFF636466)      // #636466
val TecGrayLight = Color(0xFF9C9EA0) // #9C9EA0

val White = Color(0xFFFFFFFF)