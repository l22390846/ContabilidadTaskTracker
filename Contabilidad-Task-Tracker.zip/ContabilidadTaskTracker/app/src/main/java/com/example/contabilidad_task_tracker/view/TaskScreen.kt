package com.example.contabilidad_task_tracker.view

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.contabilidad_task_tracker.viewmodel.TaskFilter
import com.example.contabilidad_task_tracker.viewmodel.TaskViewModel

/**
 * View (UI) - Jetpack Compose
 * Pantalla principal de la app de tareas para Contabilidad.
 *
 * Responsabilidades:
 * - Renderizar la interfaz (TopBar, input, botones, filtros, lista)
 * - Mostrar el estado expuesto por el ViewModel (MVVM)
 * - Disparar eventos hacia el ViewModel (agregar, filtrar, completar, borrar)
 *
 * Nota:
 * Esta pantalla NO contiene lógica de negocio (validación/BD).
 * Todo eso se maneja en TaskViewModel.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskScreen(vm: TaskViewModel = viewModel()) {

    // Scaffold: estructura general (TopBar + contenido)
    Scaffold(
        topBar = {
            // Barra superior con colores institucionales (vienen del Theme)
            TopAppBar(
                title = { Text("Tareas - Contabilidad") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->

        // Contenedor principal de la pantalla
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            /**
             * Input de tarea:
             * - value: estado del ViewModel
             * - onValueChange: evento hacia el ViewModel
             * - ENTER: onDone -> vm.addTask()
             * - error: se muestra si ViewModel detecta entrada inválida
             */
            OutlinedTextField(
                value = vm.inputText,
                onValueChange = vm::onInputChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Nueva tarea") },
                singleLine = true,
                isError = vm.errorMessage != null,
                supportingText = {
                    if (vm.errorMessage != null) Text(vm.errorMessage ?: "")
                    else Text("Presiona ENTER o toca Agregar")
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { vm.addTask() })
            )

            /**
             * Acciones rápidas:
             * - Eliminar completadas: borra solo tareas con isDone = true
             * - Borrar todo: elimina todas las tareas
             *
             * (Estas operaciones se ejecutan en el ViewModel, no aquí.)
             */
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.End)
            ) {
                TextButton(onClick = { vm.deleteCompleted() }) { Text("Eliminar completadas") }
                TextButton(onClick = { vm.deleteAll() }) { Text("Borrar todo") }
            }

            /**
             * Resumen visual (para presentación):
             * Muestra contadores calculados desde el ViewModel.
             */
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Pendientes: ${vm.pendingCount}")
                    Text("Completadas: ${vm.doneCount}")
                }
            }

            /**
             * Filtros de vista:
             * Cambian el filtro en el ViewModel:
             * - Todas
             * - Pendientes
             * - Hechas
             */
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = vm.filter == TaskFilter.ALL,
                    onClick = { vm.onFilterChange(TaskFilter.ALL) },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 3)
                ) { Text("Todas") }

                SegmentedButton(
                    selected = vm.filter == TaskFilter.PENDING,
                    onClick = { vm.onFilterChange(TaskFilter.PENDING) },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 3)
                ) { Text("Pendientes") }

                SegmentedButton(
                    selected = vm.filter == TaskFilter.DONE,
                    onClick = { vm.onFilterChange(TaskFilter.DONE) },
                    shape = SegmentedButtonDefaults.itemShape(index = 2, count = 3)
                ) { Text("Hechas") }
            }

            /**
             * Estado vacío:
             * Si el filtro no tiene tareas, se muestra una tarjeta informativa.
             */
            if (vm.filteredTasks.isEmpty()) {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("No hay tareas en este filtro.")
                        Text("Agrega una tarea arriba para comenzar.")
                    }
                }
            } else {

                /**
                 * Lista de tareas (estructurada):
                 * Se usa LazyColumn para rendimiento y una presentación clara.
                 * La lista usa vm.filteredTasks para respetar el filtro activo.
                 */
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(vm.filteredTasks, key = { it.id }) { task ->

                        // Tarjeta por tarea
                        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                /**
                                 * Checkbox:
                                 * Al cambiar, se notifica al ViewModel para alternar estado completado.
                                 */
                                Checkbox(
                                    checked = task.isDone,
                                    onCheckedChange = { vm.toggleDone(task.id) }
                                )

                                Spacer(Modifier.width(10.dp))

                                /**
                                 * Texto de tarea:
                                 * - Se tacha cuando está completada (confirmación visual).
                                 */
                                Text(
                                    text = task.title,
                                    modifier = Modifier.weight(1f),
                                    style = MaterialTheme.typography.bodyLarge,
                                    textDecoration = if (task.isDone) TextDecoration.LineThrough else null
                                )

                                // Confirmación visual adicional si está completada
                                if (task.isDone) {
                                    Text("✔", style = MaterialTheme.typography.titleMedium)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
