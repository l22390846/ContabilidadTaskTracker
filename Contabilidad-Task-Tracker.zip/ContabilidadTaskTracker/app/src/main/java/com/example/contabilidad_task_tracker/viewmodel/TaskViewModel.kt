package com.example.contabilidad_task_tracker.viewmodel

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.contabilidad_task_tracker.data.AppDatabase
import com.example.contabilidad_task_tracker.data.TaskEntity
import com.example.contabilidad_task_tracker.model.TaskItem
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Filtros disponibles para visualizar tareas en la UI.
 * - ALL: muestra todas
 * - PENDING: solo pendientes
 * - DONE: solo completadas
 */
enum class TaskFilter { ALL, PENDING, DONE }

/**
 * ViewModel (MVVM)
 * Responsable de:
 * - Mantener el estado de la pantalla (input, error, filtro, lista)
 * - Validar la entrada del usuario
 * - Coordinar acciones con la base de datos (Room) mediante DAO
 * - Exponer estados observables para recomposición automática en Compose
 *
 * Nota:
 * Se usa AndroidViewModel porque necesitamos Application para construir la BD local.
 */
class TaskViewModel(app: Application) : AndroidViewModel(app) {

    // ===== Data Layer (Room) =====

    /**
     * Instancia de la base de datos local (Room).
     * Nombre del archivo: contabilidad_tasks.db
     */
    private val db = Room.databaseBuilder(
        app,
        AppDatabase::class.java,
        "contabilidad_tasks.db"
    ).build()

    /** DAO para operaciones de tareas (consultar, guardar, marcar, borrar). */
    private val dao = db.taskDao()

    // ===== UI State (Estado para Compose) =====

    /** Texto que escribe el usuario en el input "Nueva tarea". */
    var inputText by mutableStateOf("")
        private set

    /** Mensaje de error si el usuario intenta agregar una tarea inválida. */
    var errorMessage by mutableStateOf<String?>(null)
        private set

    /** Filtro actual seleccionado por el usuario (Todas / Pendientes / Hechas). */
    var filter by mutableStateOf(TaskFilter.ALL)
        private set

    /**
     * Lista de tareas que consume la UI.
     * Se actualiza cuando Room emite cambios (Flow).
     */
    var tasks by mutableStateOf<List<TaskItem>>(emptyList())
        private set

    /**
     * Lista filtrada según el filtro seleccionado.
     * derivedStateOf asegura recomposición cuando cambian 'filter' o 'tasks'.
     */
    val filteredTasks by derivedStateOf {
        when (filter) {
            TaskFilter.ALL -> tasks
            TaskFilter.PENDING -> tasks.filter { !it.isDone }
            TaskFilter.DONE -> tasks.filter { it.isDone }
        }
    }

    /** Cantidad de tareas pendientes (para resumen en UI). */
    val pendingCount: Int get() = tasks.count { !it.isDone }

    /** Cantidad de tareas completadas (para resumen en UI). */
    val doneCount: Int get() = tasks.count { it.isDone }

    /**
     * Al iniciar el ViewModel:
     * - Observa la base de datos en tiempo real (Flow)
     * - Convierte entidades (TaskEntity) a modelo de UI (TaskItem)
     * - Actualiza 'tasks' para que Compose redibuje automáticamente
     */
    init {
        viewModelScope.launch {
            dao.observeAll().collectLatest { entities ->
                tasks = entities.map { it.toUi() }
            }
        }
    }

    // ===== Events (Acciones disparadas por la UI) =====

    /**
     * Actualiza el texto del input en tiempo real.
     * Si había error, lo limpia cuando el usuario empieza a escribir.
     */
    fun onInputChange(newValue: String) {
        inputText = newValue
        if (!errorMessage.isNullOrBlank()) errorMessage = null
    }

    /** Cambia el filtro seleccionado para actualizar la lista mostrada en UI. */
    fun onFilterChange(newFilter: TaskFilter) {
        filter = newFilter
    }

    /**
     * Agrega una tarea nueva.
     * - Valida que no esté vacía
     * - Guarda en Room usando DAO (upsert)
     * - Limpia input y error si todo salió bien
     */
    fun addTask() {
        val cleaned = inputText.trim()
        if (cleaned.isBlank()) {
            errorMessage = "Debes escribir una tarea."
            return
        }

        viewModelScope.launch {
            dao.upsert(
                TaskEntity(
                    id = UUID.randomUUID().toString(),
                    title = cleaned,
                    isDone = false,
                    createdAt = System.currentTimeMillis()
                )
            )
        }

        inputText = ""
        errorMessage = null
    }

    /**
     * Alterna el estado de completado de una tarea.
     * - Busca la tarea en la lista actual
     * - Envía actualización a Room (DAO)
     */
    fun toggleDone(taskId: String) {
        val current = tasks.firstOrNull { it.id == taskId } ?: return
        viewModelScope.launch {
            dao.setDone(taskId, !current.isDone)
        }
    }

    /** Elimina de la base de datos todas las tareas que estén completadas. */
    fun deleteCompleted() {
        viewModelScope.launch { dao.deleteCompleted() }
    }

    /** Elimina TODAS las tareas de la base de datos. */
    fun deleteAll() {
        viewModelScope.launch { dao.deleteAll() }
    }

    // ===== Mappers (Conversión de datos) =====

    /** Convierte una entidad de BD (TaskEntity) a modelo de UI (TaskItem). */
    private fun TaskEntity.toUi(): TaskItem =
        TaskItem(id = id, title = title, isDone = isDone)
}
